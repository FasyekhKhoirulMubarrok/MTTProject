package id.ac.ubaya.informatika.d_160418016_felixtanjiro_gachaguess

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class PemenangActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pemenang)
    }
}